<?php
/**
 * Copyright © 2015 Bakeway. All rights reserved.
 */

namespace Bakeway\CommsionLog\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
	
        $installer = $setup;

        $installer->startSetup();

		/**
         * Create table 'commsionlog_commison'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable('commsionlog_commison')
        )
		->addColumn(
            'id',
            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
            null,
            ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
            'commsionlog_commison'
        )
		->addColumn(
            'commision',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'Commision'
        )
		->addColumn(
            'setdate',
            \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
            null,
            ['nullable' => false],
            'setdate'
        )
		->addColumn(
            'setby',
            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            '64k',
            [],
            'setby'
        )
		/*{{CedAddTableColumn}}}*/
		
		
        ->setComment(
            'Bakeway CommsionLog commsionlog_commison'
        );
		
		$installer->getConnection()->createTable($table);
		/*{{CedAddTable}}*/

        $installer->endSetup();

    }
}
