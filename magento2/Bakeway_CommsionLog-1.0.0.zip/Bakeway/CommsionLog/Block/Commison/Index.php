<?php
/**
 * Copyright © 2015 Bakeway . All rights reserved.
 */
namespace Bakeway\CommsionLog\Block\Commison;
use Bakeway\CommsionLog\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
