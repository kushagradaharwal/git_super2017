<?php
namespace Bakeway\CommsionLog\Block\Adminhtml\Commison\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_commison_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Commison Information'));
    }
}