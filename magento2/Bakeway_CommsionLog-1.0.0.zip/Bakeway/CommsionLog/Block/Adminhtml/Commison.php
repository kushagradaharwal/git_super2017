<?php
namespace Bakeway\CommsionLog\Block\Adminhtml;
class Commison extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_commison';/*block grid.php directory*/
        $this->_blockGroup = 'Bakeway_CommsionLog';
        $this->_headerText = __('Commison');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}
